/* ════════════════════════════════════════════════════════════
   KRUGER.AI — Main JavaScript
   Three.js 3D City · Smartphone · Particles · Scroll Magic
   ════════════════════════════════════════════════════════════ */

'use strict';

/* ──────────────────────── UTILS ──────────────────────── */
const qs = (sel, ctx = document) => ctx.querySelector(sel);
const lerp = (a, b, t) => a + (b - a) * t;
const clamp = (v, min, max) => Math.min(Math.max(v, min), max);
const mapRange = (v, inMin, inMax, outMin, outMax) =>
  outMin + ((v - inMin) / (inMax - inMin)) * (outMax - outMin);

/* ──────────────────────── NAV SCROLL EFFECT ──────────────────────── */
(function initNav() {
  const nav = qs('#main-nav');
  let ticking = false;

  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        if (window.scrollY > 40) nav.classList.add('scrolled');
        else nav.classList.remove('scrolled');
        ticking = false;
      });
      ticking = true;
    }
  }, { passive: true });
})();

/* ──────────────────────── CURSOR GLOW ──────────────────────── */
(function initCursorGlow() {
  const glow = document.createElement('div');
  glow.className = 'cursor-glow';
  document.body.appendChild(glow);

  let mx = -400, my = -400;
  let cx = -400, cy = -400;

  document.addEventListener('mousemove', e => {
    mx = e.clientX;
    my = e.clientY;
  });

  function tick() {
    cx = lerp(cx, mx, 0.1);
    cy = lerp(cy, my, 0.1);
    glow.style.left = cx + 'px';
    glow.style.top = cy + 'px';
    requestAnimationFrame(tick);
  }
  tick();
})();

/* ──────────────────────── INTERSECTION OBSERVER REVEALS ──────────────────────── */
(function initReveal() {
  const els = document.querySelectorAll('.reveal, .testimonial-card, .pricing-card');
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.15 });
  els.forEach(el => io.observe(el));

  // Feature blocks staggered
  const featureBlocks = document.querySelectorAll('.feature-block');
  const fio = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        const idx = parseInt(e.target.dataset.index || '0');
        setTimeout(() => {
          e.target.classList.add('visible');
        }, idx * 100);
        fio.unobserve(e.target);
      }
    });
  }, { threshold: 0.1 });
  featureBlocks.forEach(el => fio.observe(el));
})();

/* ══════════════════════════════════════════════════════════════════
   THREE.JS HERO — 3D CITY + FLYOVER + SMARTPHONE
   ══════════════════════════════════════════════════════════════════ */
(function initHeroThree() {
  const canvas = qs('#hero-canvas');
  if (!canvas || typeof THREE === 'undefined') return;

  /* Scene Setup */
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x080808);
  scene.fog = new THREE.FogExp2(0x0B0B0B, 0.018);

  /* Camera */
  const camera = new THREE.PerspectiveCamera(55, canvas.clientWidth / canvas.clientHeight, 0.1, 300);
  camera.position.set(0, 12, 42);
  camera.lookAt(0, 0, 0);

  /* Renderer */
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(canvas.clientWidth, canvas.clientHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.9;

  /* ── LIGHTS ── */
  // Ambient
  const ambientLight = new THREE.AmbientLight(0x1a1a1a, 2.0);
  scene.add(ambientLight);

  // Key light (warm top)
  const keyLight = new THREE.DirectionalLight(0xffffff, 3.0);
  keyLight.position.set(15, 40, 20);
  keyLight.castShadow = true;
  keyLight.shadow.mapSize.set(2048, 2048);
  keyLight.shadow.camera.near = 0.1;
  keyLight.shadow.camera.far = 200;
  keyLight.shadow.camera.left = -60;
  keyLight.shadow.camera.right = 60;
  keyLight.shadow.camera.top = 60;
  keyLight.shadow.camera.bottom = -60;
  scene.add(keyLight);

  // Fill light (cool left)
  const fillLight = new THREE.DirectionalLight(0x8888aa, 0.8);
  fillLight.position.set(-20, 10, -10);
  scene.add(fillLight);

  // Rim light (from behind)
  const rimLight = new THREE.DirectionalLight(0xffffff, 1.5);
  rimLight.position.set(0, -5, -30);
  scene.add(rimLight);

  // Ground plane light (upward bounce)
  const groundBounce = new THREE.PointLight(0x222222, 2.0, 80);
  groundBounce.position.set(0, -8, 0);
  scene.add(groundBounce);

  /* ── MATERIALS ── */
  const matConcrete = new THREE.MeshStandardMaterial({
    color: 0x1a1a1a, roughness: 0.85, metalness: 0.05
  });
  const matMetal = new THREE.MeshStandardMaterial({
    color: 0x2a2a2a, roughness: 0.3, metalness: 0.95
  });
  const matGlass = new THREE.MeshStandardMaterial({
    color: 0x111122, roughness: 0.05, metalness: 0.1,
    transparent: true, opacity: 0.55
  });
  const matLED = new THREE.MeshStandardMaterial({
    color: 0xffffff, emissive: 0xffffff, emissiveIntensity: 1.5,
    roughness: 0.1, metalness: 0
  });
  const matGlassScreen = new THREE.MeshStandardMaterial({
    color: 0x050510, roughness: 0.02, metalness: 0.2,
    transparent: true, opacity: 0.92
  });
  const matPhoneBody = new THREE.MeshStandardMaterial({
    color: 0x111111, roughness: 0.15, metalness: 0.98
  });

  /* ──────────────────────── GROUND ──────────────────────── */
  const groundGeo = new THREE.PlaneGeometry(300, 300);
  const groundMat = new THREE.MeshStandardMaterial({
    color: 0x0a0a0a, roughness: 0.9, metalness: 0.0
  });
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -8;
  ground.receiveShadow = true;
  scene.add(ground);

  /* ──────────────────────── BUILDING GENERATOR ──────────────────────── */
  function createBuilding(x, z, width, depth, height, windowRows, hasGlassFace) {
    const group = new THREE.Group();

    // Concrete base
    const baseGeo = new THREE.BoxGeometry(width, height, depth);
    const baseMesh = new THREE.Mesh(baseGeo, matConcrete);
    baseMesh.castShadow = true;
    baseMesh.receiveShadow = true;
    baseMesh.position.y = height / 2;
    group.add(baseMesh);

    // Glass facade on front face (z+ direction)
    if (hasGlassFace) {
      const glassGeo = new THREE.PlaneGeometry(width * 0.9, height * 0.85);
      const glassMesh = new THREE.Mesh(glassGeo, matGlass);
      glassMesh.position.set(0, height / 2, depth / 2 + 0.02);
      group.add(glassMesh);

      // Window grid using LED material
      const windowsGroup = new THREE.Group();
      const wCols = Math.floor(width / 1.2);
      const wRows = Math.floor(height / 1.8);
      const wGeo = new THREE.PlaneGeometry(0.5, 0.7);

      for (let r = 0; r < wRows; r++) {
        for (let c = 0; c < wCols; c++) {
          if (Math.random() > 0.3) { // 70% lit windows
            const wMat = new THREE.MeshStandardMaterial({
              color: 0xffffff,
              emissive: 0xffffff,
              emissiveIntensity: Math.random() * 0.4 + 0.05,
              roughness: 0.1, metalness: 0
            });
            const w = new THREE.Mesh(wGeo, wMat);
            w.position.set(
              (c - wCols / 2 + 0.5) * 1.2,
              (r - wRows / 2 + 0.5) * 1.8 + height / 2,
              depth / 2 + 0.04
            );
            windowsGroup.add(w);
          }
        }
      }
      group.add(windowsGroup);
    }

    // Metal top cap
    const capGeo = new THREE.BoxGeometry(width + 0.2, 0.4, depth + 0.2);
    const cap = new THREE.Mesh(capGeo, matMetal);
    cap.position.y = height + 0.2;
    group.add(cap);

    // LED strip on cap
    const ledGeo = new THREE.BoxGeometry(width - 0.5, 0.05, depth - 0.5);
    const led = new THREE.Mesh(ledGeo, matLED);
    led.position.y = height + 0.42;
    group.add(led);

    group.position.set(x, -8, z);
    scene.add(group);
    return group;
  }

  /* ──────────────────────── CITY LAYOUT ──────────────────────── */
  const buildings = [];
  const cityLayout = [
    // Far background row
    { x: -55, z: -70, w: 10, d: 12, h: 55, g: true },
    { x: -40, z: -65, w: 8,  d: 10, h: 42, g: true },
    { x: -25, z: -72, w: 12, d: 14, h: 65, g: true },
    { x:  -8, z: -68, w: 9,  d: 11, h: 50, g: true },
    { x:   8, z: -75, w: 10, d: 13, h: 70, g: true },
    { x:  22, z: -62, w: 8,  d: 9,  h: 40, g: false },
    { x:  36, z: -70, w: 12, d: 14, h: 58, g: true },
    { x:  52, z: -65, w: 9,  d: 11, h: 45, g: true },

    // Mid row
    { x: -50, z: -40, w: 8,  d: 10, h: 32, g: false },
    { x: -36, z: -45, w: 10, d: 12, h: 38, g: true },
    { x: -20, z: -38, w: 7,  d: 8,  h: 25, g: false },
    { x:  22, z: -42, w: 7,  d: 9,  h: 28, g: false },
    { x:  38, z: -40, w: 9,  d: 11, h: 35, g: true },
    { x:  52, z: -38, w: 8,  d: 10, h: 30, g: false },

    // Near sides
    { x: -55, z: -15, w: 7,  d: 9,  h: 22, g: false },
    { x: -42, z: -10, w: 8,  d: 10, h: 18, g: true },
    { x:  44, z: -12, w: 8,  d: 10, h: 20, g: true },
    { x:  56, z: -8,  w: 7,  d: 9,  h: 16, g: false },
  ];

  cityLayout.forEach(b => {
    const building = createBuilding(b.x, b.z, b.w, b.d, b.h, 8, b.g);
    buildings.push(building);
  });

  /* ──────────────────────── FLYOVER BRIDGE ──────────────────────── */
  function createFlyover() {
    const flyGroup = new THREE.Group();

    // Main curved deck using a custom shape
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-60, 14, -20),
      new THREE.Vector3(-30, 16, -10),
      new THREE.Vector3(0,   18, -2),
      new THREE.Vector3(30,  16, -10),
      new THREE.Vector3(60,  14, -20),
    ]);

    const tubeSegments = 80;
    const points = curve.getPoints(tubeSegments);

    // Deck planks
    for (let i = 0; i < tubeSegments; i++) {
      const p0 = points[i];
      const p1 = points[i + 1];
      if (!p0 || !p1) continue;

      const mid = new THREE.Vector3().addVectors(p0, p1).multiplyScalar(0.5);
      const dir = new THREE.Vector3().subVectors(p1, p0).normalize();
      const len = p0.distanceTo(p1);

      // Concrete deck slab
      const slabGeo = new THREE.BoxGeometry(len + 0.05, 0.4, 9);
      const slab = new THREE.Mesh(slabGeo, matConcrete);
      // Give the flyover a slight emissive glow so it stands out more
      slab.material = slab.material.clone();
      slab.material.emissive.setHex(0x111111);
      slab.material.emissiveIntensity = 0.5;
      slab.castShadow = true;
      slab.receiveShadow = true;
      slab.position.copy(mid);
      const quaternion = new THREE.Quaternion();
      quaternion.setFromUnitVectors(new THREE.Vector3(1, 0, 0), dir);
      slab.setRotationFromQuaternion(quaternion);
      flyGroup.add(slab);

      // Glass railings
      if (i % 3 === 0) {
        const railH = 1.4;
        for (const side of [-3.8, 3.8]) {
          const railGeo = new THREE.BoxGeometry(len * 3, railH, 0.08);
          const rail = new THREE.Mesh(railGeo, matGlass);
          rail.position.copy(mid);
          rail.position.y += 0.5 + railH / 2;
          rail.position.z += side;
          rail.setRotationFromQuaternion(quaternion);
          flyGroup.add(rail);
        }
      }

      // LED strips on both edges
      if (i % 2 === 0) {
        for (const side of [-4.2, 4.2]) {
          const ledGeo = new THREE.BoxGeometry(len + 0.02, 0.1, 0.1);
          const ledMat = new THREE.MeshStandardMaterial({
            color: 0xffffff, emissive: 0xffaa00, emissiveIntensity: 2.0,
            roughness: 0.1, metalness: 0
          });
          const led = new THREE.Mesh(ledGeo, ledMat);
          led.position.copy(mid);
          led.position.y += 0.22;
          led.position.z += side;
          led.setRotationFromQuaternion(quaternion);
          flyGroup.add(led);
        }
      }
    }

    // Support pillars
    const pillarPositions = [-45, -20, 0, 20, 45];
    pillarPositions.forEach((px, i) => {
      const pillarH = 22 + i * 0.5;
      const pillarGeo = new THREE.CylinderGeometry(0.5, 0.7, pillarH, 8);
      const pillar = new THREE.Mesh(pillarGeo, matMetal);
      const curvePoint = curve.getPoint(0.1 + i * 0.2);
      pillar.position.set(curvePoint.x, curvePoint.y - pillarH / 2 - 4, curvePoint.z);
      pillar.castShadow = true;
      flyGroup.add(pillar);
    });

    scene.add(flyGroup);
    return flyGroup;
  }

  const flyover = createFlyover();

  /* ──────────────────────── PREMIUM SMARTPHONE ──────────────────────── */
  function createSmartphone() {
    const phoneGroup = new THREE.Group();

    const W = 3.2, H = 6.8, D = 0.18;

    // Body (rounded corners via shape)
    const bodyShape = new THREE.Shape();
    const r = 0.4;
    bodyShape.moveTo(-W / 2 + r, -H / 2);
    bodyShape.lineTo(W / 2 - r, -H / 2);
    bodyShape.quadraticCurveTo(W / 2, -H / 2, W / 2, -H / 2 + r);
    bodyShape.lineTo(W / 2, H / 2 - r);
    bodyShape.quadraticCurveTo(W / 2, H / 2, W / 2 - r, H / 2);
    bodyShape.lineTo(-W / 2 + r, H / 2);
    bodyShape.quadraticCurveTo(-W / 2, H / 2, -W / 2, H / 2 - r);
    bodyShape.lineTo(-W / 2, -H / 2 + r);
    bodyShape.quadraticCurveTo(-W / 2, -H / 2, -W / 2 + r, -H / 2);

    const extSettings = { depth: D, bevelEnabled: true, bevelThickness: 0.04, bevelSize: 0.04, bevelSegments: 4 };
    const bodyGeo = new THREE.ExtrudeGeometry(bodyShape, extSettings);
    const body = new THREE.Mesh(bodyGeo, matPhoneBody);
    body.castShadow = true;
    body.position.z = -D / 2;
    phoneGroup.add(body);

    // Screen face (slightly inset)
    const screenShape = new THREE.Shape();
    const sr = 0.3;
    const sw = W * 0.88, sh = H * 0.90;
    screenShape.moveTo(-sw / 2 + sr, -sh / 2);
    screenShape.lineTo(sw / 2 - sr, -sh / 2);
    screenShape.quadraticCurveTo(sw / 2, -sh / 2, sw / 2, -sh / 2 + sr);
    screenShape.lineTo(sw / 2, sh / 2 - sr);
    screenShape.quadraticCurveTo(sw / 2, sh / 2, sw / 2 - sr, sh / 2);
    screenShape.lineTo(-sw / 2 + sr, sh / 2);
    screenShape.quadraticCurveTo(-sw / 2, sh / 2, -sw / 2, sh / 2 - sr);
    screenShape.lineTo(-sw / 2, -sh / 2 + sr);
    screenShape.quadraticCurveTo(-sw / 2, -sh / 2, -sw / 2 + sr, -sh / 2);

    const screenGeo = new THREE.ShapeGeometry(screenShape);
    const screenMesh = new THREE.Mesh(screenGeo, matGlassScreen);
    screenMesh.position.z = D + 0.01;
    phoneGroup.add(screenMesh);

    // Camera notch / dynamic island
    const islandGeo = typeof THREE.CapsuleGeometry !== 'undefined' ? 
      new THREE.CapsuleGeometry(0.12, 0.35, 4, 8) :
      new THREE.CylinderGeometry(0.12, 0.12, 0.35, 8);
    const islandMat = new THREE.MeshStandardMaterial({ color: 0x000000, roughness: 0.8, metalness: 0.2 });
    const island = new THREE.Mesh(islandGeo, islandMat);
    island.rotation.z = Math.PI / 2;
    island.position.set(0, H * 0.42, D + 0.02);
    phoneGroup.add(island);

    // Side buttons
    const btnGeo = new THREE.BoxGeometry(0.06, 0.5, 0.08);
    const btnMat = new THREE.MeshStandardMaterial({ color: 0x333333, roughness: 0.2, metalness: 0.9 });
    [-0.3, 0.1, 0.5].forEach(by => {
      const btn = new THREE.Mesh(btnGeo, btnMat);
      btn.position.set(W / 2 + 0.02, by, D / 2);
      phoneGroup.add(btn);
    });

    // Back camera module
    const camGeo = new THREE.BoxGeometry(1.1, 1.1, 0.12);
    const camMat = new THREE.MeshStandardMaterial({ color: 0x0d0d0d, roughness: 0.3, metalness: 0.9 });
    const camModule = new THREE.Mesh(camGeo, camMat);
    camModule.position.set(-W * 0.2, H * 0.3, -D - 0.05);
    phoneGroup.add(camModule);

    // Camera lenses
    [[0.2, 0.2], [-0.2, 0.2], [0.2, -0.2]].forEach(([lx, ly]) => {
      const lensGeo = new THREE.CylinderGeometry(0.15, 0.15, 0.06, 16);
      const lensMat = new THREE.MeshStandardMaterial({
        color: 0x111111, roughness: 0.05, metalness: 0.9
      });
      const lens = new THREE.Mesh(lensGeo, lensMat);
      lens.rotation.x = Math.PI / 2;
      lens.position.set(-W * 0.2 + lx, H * 0.3 + ly, -D - 0.08);
      phoneGroup.add(lens);
    });

    // Screen content canvas texture
    const texCanvas = document.createElement('canvas');
    texCanvas.width = 512;
    texCanvas.height = 1024;
    const ctx = texCanvas.getContext('2d');
    phoneGroup.userData.screenCanvas = texCanvas;
    phoneGroup.userData.screenCtx = ctx;

    const screenTex = new THREE.CanvasTexture(texCanvas);
    phoneGroup.userData.screenTexture = screenTex;

    const screenContentGeo = new THREE.PlaneGeometry(sw * 0.99, sh * 0.99);
    const screenContentMat = new THREE.MeshBasicMaterial({
      map: screenTex,
      transparent: true
    });
    const screenContent = new THREE.Mesh(screenContentGeo, screenContentMat);
    screenContent.position.z = D + 0.012;
    phoneGroup.add(screenContent);
    phoneGroup.userData.screenContent = screenContent;

    return phoneGroup;
  }

  const phone = createSmartphone();
  phone.position.set(8, 4, 10);
  phone.rotation.y = -0.25;
  scene.add(phone);

  /* ──────────────────────── SCREEN ANIMATION ──────────────────────── */
  const platforms = [
    { name: 'Instagram', color: '#1a1a1a', accent: '#ffffff', icon: '📸', content: 'carousel' },
    { name: 'LinkedIn',  color: '#111111', accent: '#e0e0e0', icon: '💼', content: 'article' },
    { name: 'YouTube',   color: '#0d0d0d', accent: '#cccccc', icon: '▶',  content: 'thumbnail' },
    { name: 'X',         color: '#0a0a0a', accent: '#ffffff', icon: '𝕏',  content: 'thread' },
    { name: 'Facebook',  color: '#111111', accent: '#d0d0d0', icon: '𝑓',  content: 'ad' },
    { name: 'TikTok',    color: '#0c0c0c', accent: '#ffffff', icon: '♪',  content: 'reel' },
  ];

  let currentPlatform = 0;
  let screenPhase = 'platform'; // 'platform' | 'content'
  let screenProgress = 0;

  function drawPhoneScreen(platform, progress, phase) {
    const c = phone.userData.screenCtx;
    const W = 512, H = 1024;
    c.clearRect(0, 0, W, H);

    // Background
    const bgAlpha = Math.min(1, progress * 2);
    c.globalAlpha = bgAlpha;
    c.fillStyle = platform.color;
    c.fillRect(0, 0, W, H);

    // Dynamic island
    c.fillStyle = '#000000';
    c.beginPath();
    c.roundRect(W / 2 - 60, 20, 120, 30, 15);
    c.fill();

    if (phase === 'platform') {
      // Platform icon + name centered
      const alpha = Math.min(1, progress * 3);
      c.globalAlpha = alpha;

      // Large icon
      c.font = 'bold 120px Arial';
      c.textAlign = 'center';
      c.fillStyle = platform.accent;
      c.fillText(platform.icon, W / 2, H / 2 - 40);

      // Platform name
      c.font = 'bold 52px Inter, Arial';
      c.fillStyle = platform.accent;
      c.fillText(platform.name, W / 2, H / 2 + 80);

      // Slide indicator dots
      platforms.forEach((_, i) => {
        c.beginPath();
        c.arc(W / 2 - (platforms.length / 2 - 0.5) * 24 + i * 24, H * 0.82, i === currentPlatform ? 6 : 3.5, 0, Math.PI * 2);
        c.fillStyle = i === currentPlatform ? platform.accent : 'rgba(255,255,255,0.2)';
        c.fill();
      });

    } else {
      // AI-generated content phase
      const alpha = Math.min(1, progress * 2);
      c.globalAlpha = alpha;

      // App header bar
      c.fillStyle = platform.color;
      c.fillRect(0, 60, W, 70);
      c.fillStyle = platform.accent;
      c.font = '600 28px Inter, Arial';
      c.textAlign = 'left';
      c.fillText(platform.icon + '  ' + platform.name, 40, 102);

      // Content thumbnail block
      const contentProgress = Math.min(1, progress * 2);
      c.globalAlpha = alpha * contentProgress;

      // Main image area - gradient "poster"
      const gradient = c.createLinearGradient(40, 150, W - 40, 150 + H * 0.32);
      gradient.addColorStop(0, platform.color === '#0a0a0a' ? '#333333' : platform.color);
      gradient.addColorStop(1, '#050505');
      c.fillStyle = gradient;
      c.roundRect(40, 150, W - 80, H * 0.32, 16);
      c.fill();
      c.strokeStyle = 'rgba(255,255,255,0.1)';
      c.lineWidth = 2;
      c.stroke();
      
      // Abstract shapes in the poster
      c.fillStyle = platform.accent;
      c.globalAlpha = alpha * contentProgress * 0.2;
      c.beginPath();
      c.arc(W/2 + 50, 150 + H*0.16, 60, 0, Math.PI*2);
      c.fill();
      c.beginPath();
      c.arc(W/2 - 70, 150 + H*0.1, 30, 0, Math.PI*2);
      c.fill();
      
      // AI shimmer overlay
      c.globalAlpha = alpha * contentProgress;
      const shimmerX = (progress % 1) * (W + 200) - 100;
      const shimGrad = c.createLinearGradient(shimmerX - 60, 0, shimmerX + 60, 0);
      shimGrad.addColorStop(0, 'rgba(255,255,255,0)');
      shimGrad.addColorStop(0.5, 'rgba(255,255,255,0.06)');
      shimGrad.addColorStop(1, 'rgba(255,255,255,0)');
      c.fillStyle = shimGrad;
      c.roundRect(40, 150, W - 80, H * 0.32, 16);
      c.fill();

      // Content label inside image
      c.globalAlpha = alpha * Math.max(0, (contentProgress - 0.3) * 2);
      c.fillStyle = platform.accent;
      c.font = 'bold 36px Inter, Arial';
      c.textAlign = 'center';
      const contentLabels = { carousel: 'CAROUSEL', article: 'ARTICLE', thumbnail: 'THUMBNAIL', thread: 'THREAD', ad: 'ADVERTISEMENT', reel: 'REEL SCRIPT' };
      c.fillText(contentLabels[platform.content] || 'CONTENT', W / 2, 150 + H * 0.32 * 0.5 + 12);

      // Text lines below
      c.globalAlpha = alpha * Math.max(0, (contentProgress - 0.5) * 2);
      c.fillStyle = platform.accent;
      c.textAlign = 'left';

      const lineY = 150 + H * 0.32 + 36;
      c.font = '500 22px Inter, Arial';
      c.fillText('New campaign design generated ✨', 40, lineY);
      c.globalAlpha = alpha * Math.max(0, (contentProgress - 0.6) * 2.5);
      c.fillStyle = 'rgba(255,255,255,0.4)';
      c.font = '400 18px Inter, Arial';
      c.fillText('Optimized for ' + platform.name + ' audience', 40, lineY + 32);
      c.fillText('Status: Ready to publish', 40, lineY + 60);

      // AI badge
      c.globalAlpha = alpha * Math.max(0, (contentProgress - 0.7) * 3);
      c.fillStyle = 'rgba(255,255,255,0.08)';
      c.roundRect(40, lineY + 90, 160, 36, 8);
      c.fill();
      c.fillStyle = 'rgba(255,255,255,0.6)';
      c.font = '600 16px Inter, Arial';
      c.fillText('✦ AI Generated', 60, lineY + 114);
    }

    phone.userData.screenTexture.needsUpdate = true;
    c.globalAlpha = 1;
  }

  // Animate screen cycling
  let screenTime = 0;
  const PLATFORM_DUR = 2.5; // seconds per platform
  const CONTENT_DUR = 3.0;  // seconds per content

  function updatePhoneScreen(delta) {
    screenTime += delta;

    const cycleDur = PLATFORM_DUR + CONTENT_DUR;
    const cycleT = screenTime % cycleDur;
    const platformIdx = Math.floor(screenTime / cycleDur) % platforms.length;
    currentPlatform = platformIdx;

    if (cycleT < PLATFORM_DUR) {
      screenPhase = 'platform';
      screenProgress = cycleT / PLATFORM_DUR;
    } else {
      screenPhase = 'content';
      screenProgress = (cycleT - PLATFORM_DUR) / CONTENT_DUR;
    }

    drawPhoneScreen(platforms[currentPlatform], screenProgress, screenPhase);
  }

  /* ──────────────────────── PARTICLES ──────────────────────── */
  function createParticleField() {
    const count = 400;
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const sizes = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      positions[i * 3]     = (Math.random() - 0.5) * 120;
      positions[i * 3 + 1] = Math.random() * 60 - 5;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 80;
      sizes[i] = Math.random() * 1.5 + 0.3;
    }

    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('size', new THREE.BufferAttribute(sizes, 1));

    const mat = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.12,
      transparent: true,
      opacity: 0.25,
      sizeAttenuation: true
    });

    return new THREE.Points(geo, mat);
  }

  const particles = createParticleField();
  scene.add(particles);

  /* ──────────────────────── TRAFFIC SIMULATION ──────────────────────── */
  const trafficLights = [];

  function createTrafficDot(x, z) {
    const geo = new THREE.SphereGeometry(0.15, 8, 8);
    const mat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0xffffff,
      emissiveIntensity: 1.5
    });
    const dot = new THREE.Mesh(geo, mat);
    dot.position.set(x, -7.5, z);
    scene.add(dot);
    trafficLights.push({
      mesh: dot,
      speed: Math.random() * 0.12 + 0.04,
      maxZ: 30,
      minZ: -60,
      lane: z
    });
  }

  // Create some traffic dots on roads
  for (let i = 0; i < 12; i++) {
    const z = Math.random() * 90 - 60;
    const x = (i % 2 === 0) ? -12 : 12;
    createTrafficDot(x, z);
  }
  for (let i = 0; i < 8; i++) {
    createTrafficDot((Math.random() - 0.5) * 60, -80 + i * 12);
  }

  /* ──────────────────────── SCROLL PARALLAX ──────────────────────── */
  let scrollProgress = 0;
  let targetScroll = 0;

  window.addEventListener('scroll', () => {
    const maxScroll = document.body.scrollHeight - window.innerHeight;
    targetScroll = window.scrollY / maxScroll;
  }, { passive: true });

  /* ──────────────────────── CAMERA PARALLAX ON MOUSE ──────────────────────── */
  let mouseX = 0, mouseY = 0;
  let camOffX = 0, camOffY = 0;

  document.addEventListener('mousemove', e => {
    mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
    mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
  });

  /* ──────────────────────── RESIZE ──────────────────────── */
  window.addEventListener('resize', () => {
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  });

  /* ──────────────────────── MAIN LOOP ──────────────────────── */
  const clock = new THREE.Clock();
  let animFrame;

  function animate() {
    animFrame = requestAnimationFrame(animate);
    const delta = clock.getDelta();
    const elapsed = clock.getElapsedTime();

    // Smooth scroll
    scrollProgress = lerp(scrollProgress, targetScroll, 0.05);

    // Camera movement
    const baseCamY = 12 + scrollProgress * 6;
    const baseCamZ = 42 - scrollProgress * 10;

    camOffX = lerp(camOffX, mouseX * 3, 0.04);
    camOffY = lerp(camOffY, mouseY * 1.5, 0.04);

    camera.position.x = lerp(camera.position.x, camOffX, 0.04);
    camera.position.y = lerp(camera.position.y, baseCamY + camOffY, 0.04);
    camera.position.z = lerp(camera.position.z, baseCamZ, 0.04);

    camera.lookAt(0, scrollProgress * 4, 0);

    // Phone rotation
    phone.rotation.y = -0.25 + Math.sin(elapsed * 0.35) * 0.15;
    phone.position.y = 4 + Math.sin(elapsed * 0.5) * 0.3;
    phone.rotation.x = Math.sin(elapsed * 0.3) * 0.04;

    // Screen animation
    updatePhoneScreen(delta);

    // Flyover subtle movement
    flyover.position.y = Math.sin(elapsed * 0.18) * 0.2;

    // Particle drift
    particles.rotation.y += 0.0005;
    particles.position.y = Math.sin(elapsed * 0.12) * 0.3;

    // Traffic
    trafficLights.forEach(t => {
      t.mesh.position.z += t.speed;
      if (t.mesh.position.z > 30) t.mesh.position.z = -60;
    });

    // Window light flicker (subtle)
    if (Math.floor(elapsed * 3) % 20 === 0) {
      // very subtle random window change — skip for perf
    }

    renderer.render(scene, camera);
  }

  animate();

  // Cleanup on page hide
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { cancelAnimationFrame(animFrame); }
    else { animate(); }
  });
})();

/* ══════════════════════════════════════════════════════════════════
   MINI CTA CANVAS — Geometric particle field
   ══════════════════════════════════════════════════════════════════ */
(function initCtaCanvas() {
  const canvas = qs('#cta-canvas');
  if (!canvas || typeof THREE === 'undefined') return;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(60, canvas.clientWidth / canvas.clientHeight, 0.1, 100);
  camera.position.z = 20;

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
  renderer.setSize(canvas.clientWidth, canvas.clientHeight);

  // Grid of floating geometric shapes
  const shapes = [];
  const geos = [
    new THREE.OctahedronGeometry(0.6, 0),
    new THREE.TetrahedronGeometry(0.7, 0),
    new THREE.IcosahedronGeometry(0.5, 0),
    new THREE.BoxGeometry(0.9, 0.9, 0.9),
  ];

  for (let i = 0; i < 60; i++) {
    const geo = geos[Math.floor(Math.random() * geos.length)];
    const mat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.3,
      metalness: 0.8,
      transparent: true,
      opacity: Math.random() * 0.15 + 0.02
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(
      (Math.random() - 0.5) * 50,
      (Math.random() - 0.5) * 30,
      (Math.random() - 0.5) * 20
    );
    mesh.rotation.set(
      Math.random() * Math.PI,
      Math.random() * Math.PI,
      Math.random() * Math.PI
    );
    mesh.userData.rotSpeed = {
      x: (Math.random() - 0.5) * 0.008,
      y: (Math.random() - 0.5) * 0.012,
      z: (Math.random() - 0.5) * 0.006
    };
    scene.add(mesh);
    shapes.push(mesh);
  }

  const light1 = new THREE.DirectionalLight(0xffffff, 2);
  light1.position.set(5, 10, 5);
  scene.add(light1);
  scene.add(new THREE.AmbientLight(0x111111, 3));

  window.addEventListener('resize', () => {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  });

  const clock = new THREE.Clock();
  let af;

  function tick() {
    af = requestAnimationFrame(tick);
    const t = clock.getElapsedTime();
    shapes.forEach(s => {
      s.rotation.x += s.userData.rotSpeed.x;
      s.rotation.y += s.userData.rotSpeed.y;
      s.rotation.z += s.userData.rotSpeed.z;
      s.position.y += Math.sin(t * 0.3 + s.position.x) * 0.001;
    });
    renderer.render(scene, camera);
  }

  // Only start when in view
  const io = new IntersectionObserver(([entry]) => {
    if (entry.isIntersecting) { tick(); io.disconnect(); }
  }, { threshold: 0.1 });
  io.observe(canvas.parentElement);
})();

/* ══════════════════════════════════════════════════════════════════
   PROMPT TERMINAL ANIMATION
   ══════════════════════════════════════════════════════════════════ */
(function initPromptAnimation() {
  const promptInput = qs('#user-prompt-input');
  const generateBtn = qs('#generate-btn');
  const termProcessing = qs('#terminal-processing');
  const processingFill = qs('#processing-fill');
  const processingLabel = qs('#processing-label');
  const outputGrid = qs('#output-grid');
  const outputCards = document.querySelectorAll('.output-card');

  if (!promptInput || !generateBtn) return;

  const PROCESSING_STEPS = [
    { label: 'Analyzing brief...', pct: 15 },
    { label: 'Generating Instagram post...', pct: 30 },
    { label: 'Crafting LinkedIn article...', pct: 45 },
    { label: 'Designing YouTube thumbnail...', pct: 58 },
    { label: 'Writing X thread...', pct: 70 },
    { label: 'Building TikTok reel script...', pct: 82 },
    { label: 'Creating Facebook ad...', pct: 93 },
    { label: 'Finalizing campaign...', pct: 100 },
  ];

  let started = false;

  function runProcessingAnimation(onDone) {
    termProcessing.classList.add('active');
    let step = 0;

    function nextStep() {
      if (step >= PROCESSING_STEPS.length) {
        if (onDone) onDone();
        return;
      }
      const s = PROCESSING_STEPS[step];
      processingLabel.textContent = s.label;
      processingFill.style.width = s.pct + '%';
      step++;
      setTimeout(nextStep, 380);
    }
    nextStep();
  }

  function revealOutputs() {
    outputGrid.classList.add('visible');
    outputCards.forEach((card, i) => {
      setTimeout(() => {
        card.classList.add('revealed');
      }, i * 150 + 200);
    });
  }

  function runSequence() {
    if (started) return;
    started = true;
    
    // Hide previous outputs
    outputGrid.classList.remove('visible');
    outputCards.forEach(c => c.classList.remove('revealed'));
    termProcessing.classList.remove('active');
    processingFill.style.width = '0%';
    
    promptInput.disabled = true;
    generateBtn.disabled = true;
    
    // Blur input slightly while generating
    promptInput.style.opacity = '0.5';

    runProcessingAnimation(() => {
      setTimeout(() => {
        termProcessing.classList.remove('active');
        revealOutputs();
        promptInput.disabled = false;
        generateBtn.disabled = false;
        promptInput.style.opacity = '1';
        started = false;
      }, 500);
    });
  }
  
  generateBtn.addEventListener('click', () => {
    if (promptInput.value.trim() !== '') {
      runSequence();
    }
  });

  promptInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && promptInput.value.trim() !== '') {
      runSequence();
    }
  });
})();

/* ══════════════════════════════════════════════════════════════════
   SECTION LABEL & TITLE REVEALS
   ══════════════════════════════════════════════════════════════════ */
(function initSectionReveals() {
  const sectionEls = document.querySelectorAll('.section-demo .section-label, .section-demo .section-title, .section-demo .section-sub, .section-features .section-label, .section-features .section-title, .section-features .section-sub, .testimonials-wrapper .section-label, .testimonials-wrapper .section-title, .section-pricing .section-label, .section-pricing .section-title, .section-pricing .section-sub, .cta-content .section-label, .cta-headline, .cta-sub');

  sectionEls.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.8s cubic-bezier(0.22,1,0.36,1), transform 0.8s cubic-bezier(0.22,1,0.36,1)';
  });

  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.style.opacity = '1';
        e.target.style.transform = 'translateY(0)';
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.2 });

  sectionEls.forEach(el => io.observe(el));
})();

/* ══════════════════════════════════════════════════════════════════
   FEATURE BLOCK INTERACTIVE GLOW ON MOUSE
   ══════════════════════════════════════════════════════════════════ */
(function initFeatureGlow() {
  const blocks = document.querySelectorAll('.feature-block');

  blocks.forEach(block => {
    block.addEventListener('mousemove', e => {
      const rect = block.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      const glow = block.querySelector('.feature-block-glow');
      if (glow) {
        glow.style.background = `radial-gradient(circle at ${x}% ${y}%, rgba(255,255,255,0.18) 0%, transparent 60%)`;
      }
    });
  });
})();

/* ══════════════════════════════════════════════════════════════════
   SMOOTH SCROLL FOR NAV LINKS
   ══════════════════════════════════════════════════════════════════ */
(function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', e => {
      const id = link.getAttribute('href');
      if (id === '#') return;
      const target = document.querySelector(id);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });
})();

/* ══════════════════════════════════════════════════════════════════
   MOBILE NAV TOGGLE
   ══════════════════════════════════════════════════════════════════ */
(function initMobileNav() {
  const hamburger = qs('#nav-hamburger');
  const navLinks = qs('.nav-links');
  const navActions = qs('.nav-actions');

  if (!hamburger) return;

  let open = false;

  hamburger.addEventListener('click', () => {
    open = !open;
    if (open) {
      navLinks.style.display = 'flex';
      navLinks.style.flexDirection = 'column';
      navLinks.style.position = 'fixed';
      navLinks.style.top = '64px';
      navLinks.style.left = '0';
      navLinks.style.right = '0';
      navLinks.style.background = 'rgba(11,11,11,0.96)';
      navLinks.style.backdropFilter = 'blur(20px)';
      navLinks.style.padding = '24px 32px';
      navLinks.style.gap = '20px';
      navLinks.style.borderBottom = '1px solid rgba(255,255,255,0.07)';
      navLinks.style.zIndex = '999';
      hamburger.setAttribute('aria-expanded', 'true');
    } else {
      navLinks.style.display = '';
      hamburger.setAttribute('aria-expanded', 'false');
    }
  });
})();

/* ══════════════════════════════════════════════════════════════════
   PERFORMANCE: Pause Three.js when tab is hidden
   ══════════════════════════════════════════════════════════════════ */
// Already handled in initHeroThree via visibilitychange event

console.log('%cKruger.ai%c — Premium AI Landing Page', 
  'font-size:20px;font-weight:900;color:#fff;background:#0B0B0B;padding:6px 12px;border-radius:6px;',
  'font-size:13px;color:#888;padding:6px;'
);
